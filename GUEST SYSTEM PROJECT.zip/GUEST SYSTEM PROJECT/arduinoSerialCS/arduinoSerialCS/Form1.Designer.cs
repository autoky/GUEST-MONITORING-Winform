﻿namespace arduinoSerialCS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnl_connect = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tb_portName = new System.Windows.Forms.TextBox();
            this.tb_baudrate = new System.Windows.Forms.TextBox();
            this.input = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ID_RFID = new System.Windows.Forms.TextBox();
            this.lbl_conStats = new System.Windows.Forms.Label();
            this.tb_dataRecieve = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.arduinoSerialPort = new System.IO.Ports.SerialPort(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.input_max = new System.Windows.Forms.Button();
            this.max_input = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.max = new System.Windows.Forms.Label();
            this.guest = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.light = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.roof = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.waktu = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.kiri = new System.Windows.Forms.Label();
            this.kanan = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.bulb = new System.Windows.Forms.Label();
            this.debug_box = new System.Windows.Forms.TextBox();
            this.pnl_connect.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.max_input)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_connect
            // 
            this.pnl_connect.BackgroundImage = global::arduinoSerialCS.Properties.Resources.backroun_1;
            this.pnl_connect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnl_connect.Controls.Add(this.panel5);
            this.pnl_connect.Controls.Add(this.tb_dataRecieve);
            this.pnl_connect.Controls.Add(this.label3);
            this.pnl_connect.Controls.Add(this.label5);
            this.pnl_connect.Controls.Add(this.splitter1);
            this.pnl_connect.Location = new System.Drawing.Point(-6, 12);
            this.pnl_connect.Name = "pnl_connect";
            this.pnl_connect.Size = new System.Drawing.Size(1370, 112);
            this.pnl_connect.TabIndex = 0;
            this.pnl_connect.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_connect_Paint);
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = global::arduinoSerialCS.Properties.Resources.images__1_;
            this.panel5.Controls.Add(this.tb_portName);
            this.panel5.Controls.Add(this.tb_baudrate);
            this.panel5.Controls.Add(this.input);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.ID_RFID);
            this.panel5.Controls.Add(this.lbl_conStats);
            this.panel5.Location = new System.Drawing.Point(3, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(404, 112);
            this.panel5.TabIndex = 10;
            // 
            // tb_portName
            // 
            this.tb_portName.Location = new System.Drawing.Point(85, 16);
            this.tb_portName.Name = "tb_portName";
            this.tb_portName.Size = new System.Drawing.Size(100, 20);
            this.tb_portName.TabIndex = 2;
            // 
            // tb_baudrate
            // 
            this.tb_baudrate.Location = new System.Drawing.Point(85, 42);
            this.tb_baudrate.Name = "tb_baudrate";
            this.tb_baudrate.Size = new System.Drawing.Size(100, 20);
            this.tb_baudrate.TabIndex = 3;
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(191, 42);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(167, 20);
            this.input.TabIndex = 4;
            this.input.Text = "CONNECT";
            this.input.UseVisualStyleBackColor = true;
            this.input.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(15, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baudrate";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(15, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "ID";
            this.label13.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "PORT";
            // 
            // ID_RFID
            // 
            this.ID_RFID.Location = new System.Drawing.Point(85, 68);
            this.ID_RFID.Name = "ID_RFID";
            this.ID_RFID.Size = new System.Drawing.Size(273, 20);
            this.ID_RFID.TabIndex = 3;
            // 
            // lbl_conStats
            // 
            this.lbl_conStats.AutoSize = true;
            this.lbl_conStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_conStats.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_conStats.Location = new System.Drawing.Point(239, 19);
            this.lbl_conStats.Name = "lbl_conStats";
            this.lbl_conStats.Size = new System.Drawing.Size(73, 13);
            this.lbl_conStats.TabIndex = 5;
            this.lbl_conStats.Text = "Disconnected";
            // 
            // tb_dataRecieve
            // 
            this.tb_dataRecieve.Location = new System.Drawing.Point(94, 617);
            this.tb_dataRecieve.Name = "tb_dataRecieve";
            this.tb_dataRecieve.Size = new System.Drawing.Size(100, 20);
            this.tb_dataRecieve.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 620);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Data Recieve";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Impact", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(413, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(572, 60);
            this.label5.TabIndex = 5;
            this.label5.Text = "GUEST MONITORING SYSTEM";
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(10, 112);
            this.splitter1.TabIndex = 8;
            this.splitter1.TabStop = false;
            // 
            // arduinoSerialPort
            // 
            this.arduinoSerialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.arduinoSerialPort_DataReceived);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(26, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "INPUT MAX";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.input_max);
            this.panel1.Controls.Add(this.max_input);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(12, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(389, 101);
            this.panel1.TabIndex = 1;
            // 
            // input_max
            // 
            this.input_max.Location = new System.Drawing.Point(200, 44);
            this.input_max.Name = "input_max";
            this.input_max.Size = new System.Drawing.Size(140, 31);
            this.input_max.TabIndex = 2;
            this.input_max.Text = "SEND";
            this.input_max.UseVisualStyleBackColor = true;
            this.input_max.Click += new System.EventHandler(this.input_max_Click);
            // 
            // max_input
            // 
            this.max_input.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.max_input.Location = new System.Drawing.Point(27, 44);
            this.max_input.Name = "max_input";
            this.max_input.Size = new System.Drawing.Size(167, 31);
            this.max_input.TabIndex = 0;
            this.max_input.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.max_input.ValueChanged += new System.EventHandler(this.max_input_ValueChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.progressBar1);
            this.panel2.Controls.Add(this.max);
            this.panel2.Controls.Add(this.guest);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Location = new System.Drawing.Point(407, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(931, 209);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(222, 23);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(473, 37);
            this.progressBar1.TabIndex = 6;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // max
            // 
            this.max.AutoSize = true;
            this.max.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.max.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.max.Location = new System.Drawing.Point(788, 97);
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(39, 42);
            this.max.TabIndex = 1;
            this.max.Text = "0";
            this.max.Click += new System.EventHandler(this.label7_Click);
            // 
            // guest
            // 
            this.guest.AutoSize = true;
            this.guest.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.guest.Location = new System.Drawing.Point(125, 97);
            this.guest.Name = "guest";
            this.guest.Size = new System.Drawing.Size(39, 42);
            this.guest.TabIndex = 1;
            this.guest.Text = "0";
            this.guest.Click += new System.EventHandler(this.label7_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("OCR A Extended", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(715, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(178, 39);
            this.label15.TabIndex = 5;
            this.label15.Text = "MAXIMUM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("OCR A Extended", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(72, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 39);
            this.label14.TabIndex = 5;
            this.label14.Text = "GUEST";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.light);
            this.panel3.Location = new System.Drawing.Point(12, 237);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(389, 103);
            this.panel3.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("OCR A Extended", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(20, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(201, 39);
            this.label6.TabIndex = 5;
            this.label6.Text = "LIGHTING";
            // 
            // light
            // 
            this.light.AutoSize = true;
            this.light.BackColor = System.Drawing.Color.Transparent;
            this.light.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.light.ForeColor = System.Drawing.Color.Red;
            this.light.Location = new System.Drawing.Point(244, 33);
            this.light.Name = "light";
            this.light.Size = new System.Drawing.Size(82, 37);
            this.light.TabIndex = 1;
            this.light.Text = "OFF";
            this.light.Click += new System.EventHandler(this.label7_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.roof);
            this.panel4.Location = new System.Drawing.Point(12, 346);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(389, 103);
            this.panel4.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("OCR A Extended", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(20, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 39);
            this.label8.TabIndex = 5;
            this.label8.Text = "ROOF";
            // 
            // roof
            // 
            this.roof.AutoSize = true;
            this.roof.BackColor = System.Drawing.Color.Transparent;
            this.roof.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roof.ForeColor = System.Drawing.Color.Red;
            this.roof.Location = new System.Drawing.Point(244, 33);
            this.roof.Name = "roof";
            this.roof.Size = new System.Drawing.Size(82, 37);
            this.roof.TabIndex = 1;
            this.roof.Text = "OFF";
            this.roof.Click += new System.EventHandler(this.label7_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(232, 571);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 39);
            this.label10.TabIndex = 1;
            this.label10.Text = "WIB";
            // 
            // waktu
            // 
            this.waktu.AutoSize = true;
            this.waktu.BackColor = System.Drawing.Color.Transparent;
            this.waktu.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waktu.ForeColor = System.Drawing.SystemColors.Control;
            this.waktu.Location = new System.Drawing.Point(67, 571);
            this.waktu.Name = "waktu";
            this.waktu.Size = new System.Drawing.Size(159, 39);
            this.waktu.TabIndex = 1;
            this.waktu.Text = "00:00:00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(131, 526);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 39);
            this.label12.TabIndex = 1;
            this.label12.Text = "PUKUL";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImage = global::arduinoSerialCS.Properties.Resources.SMK_Bisa_V1_white;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(1129, 526);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(209, 191);
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // kiri
            // 
            this.kiri.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.kiri.Location = new System.Drawing.Point(500, 350);
            this.kiri.Name = "kiri";
            this.kiri.Size = new System.Drawing.Size(251, 23);
            this.kiri.TabIndex = 13;
            this.kiri.Text = "                  ";
            // 
            // kanan
            // 
            this.kanan.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.kanan.Location = new System.Drawing.Point(950, 350);
            this.kanan.Name = "kanan";
            this.kanan.Size = new System.Drawing.Size(251, 23);
            this.kanan.TabIndex = 13;
            this.kanan.Text = "                  ";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(600, 373);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 192);
            this.label9.TabIndex = 13;
            this.label9.Text = "                  ";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(1081, 373);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 192);
            this.label11.TabIndex = 13;
            this.label11.Text = "                  ";
            // 
            // bulb
            // 
            this.bulb.AutoSize = true;
            this.bulb.BackColor = System.Drawing.Color.Transparent;
            this.bulb.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bulb.ForeColor = System.Drawing.Color.White;
            this.bulb.Location = new System.Drawing.Point(780, 435);
            this.bulb.Name = "bulb";
            this.bulb.Size = new System.Drawing.Size(155, 108);
            this.bulb.TabIndex = 14;
            this.bulb.Text = "💡";
            // 
            // debug_box
            // 
            this.debug_box.Location = new System.Drawing.Point(26, 666);
            this.debug_box.Name = "debug_box";
            this.debug_box.Size = new System.Drawing.Size(283, 20);
            this.debug_box.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::arduinoSerialCS.Properties.Resources.backroun_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.debug_box);
            this.Controls.Add(this.bulb);
            this.Controls.Add(this.kanan);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.kiri);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.waktu);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_connect);
            this.Controls.Add(this.panel3);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_connect.ResumeLayout(false);
            this.pnl_connect.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.max_input)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_connect;
        private System.Windows.Forms.Label lbl_conStats;
        private System.Windows.Forms.TextBox tb_baudrate;
        private System.Windows.Forms.TextBox tb_portName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.IO.Ports.SerialPort arduinoSerialPort;
        private System.Windows.Forms.TextBox tb_dataRecieve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ID_RFID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown max_input;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label light;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label roof;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label waktu;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label max;
        private System.Windows.Forms.Label guest;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button input;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button input_max;
        private System.Windows.Forms.Label kiri;
        private System.Windows.Forms.Label kanan;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label bulb;
        private System.Windows.Forms.TextBox debug_box;
    }
}

