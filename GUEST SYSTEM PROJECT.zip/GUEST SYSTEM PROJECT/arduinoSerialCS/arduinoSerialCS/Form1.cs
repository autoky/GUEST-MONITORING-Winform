﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace arduinoSerialCS
{
  
    public partial class Form1 : Form
    {
        private int guestt = 0;
        private int lampu = 0;
        private int air = 0;
        private string id = "";
        string getData;
        private Timer timer = new Timer();
        int tamu;
        decimal prog;
        public Form1()
        {
            InitializeComponent();
            firebase_init();
            timer.Interval = 1000;

            // Tambahkan event handler untuk event Tick
            timer.Tick += Timer_Tick;

            // Jalankan timer
            timer.Start();
        }

        IFirebaseConfig Config = new FirebaseConfig
        {
            AuthSecret = "bFyj9NdU8Uc2NGbfPoVxWhuAqoQDSwzj0IYiQ4WW",
            BasePath = "https://tesfirebase-a85ea-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        private void firebase_init()
        {
            client = new FireSharp.FirebaseClient(Config);

            if (client != null)
            {
                Console.WriteLine("Firebase berhasil tersambung!");
            }

            else
            {
                MessageBox.Show("Tidak dapat terhubung ke firebase!")  ;
            }
        }

        private async void firebase_update()
        {
            var intiData = new data
            {
                guesttt = guestt,
                cahaya = lampu,
                hujan = air,
                idcard = id
         

            };

            try
            {
                SetResponse resp = await client.SetTaskAsync("SensorsVal/" + "1", intiData);

                data result = resp.ResultAs<data>();
                Console.WriteLine("data berhasil dikirim ke firebase!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("gagal");
                return;
            }



        }
        private void SaveDataToCSV(string filePath)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                   sw.WriteLine($"{guestt},{lampu},{air},{id}");
                }

            }
            catch (Exception ex)
            {
               Console.WriteLine("Terjadi kesalahan: " + ex.Message);
            }
        }

        internal class data
        {
           
            public int guesttt { get; set; }
            public int cahaya { get; set; }
            public int  hujan { get; set; }
            public string idcard { get; set; }

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Perbarui label waktu dengan waktu saat ini
            waktu.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (input.Text == "CONNECT")
            {
                try
                {
                    arduinoSerialPort.PortName = tb_portName.Text;
                    arduinoSerialPort.BaudRate = Convert.ToInt32(tb_baudrate.Text);
                    arduinoSerialPort.Open();

                    if (arduinoSerialPort.IsOpen)
                    {
                        lbl_conStats.Text = "Connected";
                        input.Text = "DISCONNECT";
                        label13.Enabled = true;
                        ID_RFID.Enabled = true;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
            else
            {
                if (arduinoSerialPort.IsOpen)
                {
                    arduinoSerialPort.Close();
                    lbl_conStats.Text = "Disconnected";
                    input.Text = "CONNECT";
                    label13.Enabled = false;
                    ID_RFID.Enabled = false;

                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string port in System.IO.Ports.SerialPort.GetPortNames())
            {
                tb_portName.Text = port;
            }
            progressBar1.Maximum = 10;
            max.Text = progressBar1.Maximum.ToString();
            //label13.Enabled = false;
            //ID_RFID.Enabled = false;

            //label4.Enabled = false;
            //label6.Enabled = false;
            //label8.Enabled = false;
            //label14.Enabled = false;
            //label15.Enabled = false;

            //guest.Enabled = false;
            //max.Enabled = false;
            //light.Enabled = false;
            //roof.Enabled = false;
            //progressBar1.Enabled = false;
            // max_input.Enabled = false;
            //input_max.Enabled = false;
        }

        private void arduinoSerialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            getData = arduinoSerialPort.ReadLine();
            this.Invoke(new EventHandler(updateData));
        }

        private void updateData(object sender, EventArgs e)
        {
            string data = getData;

            debug_box.Text = data;
           // guest.Text = data;
           // tamu = Convert.ToInt32(data.Length);
           
           
            String[] parts = getData.Split('_');
            if (parts.Length >= 4)
            {
                int Nut = Convert.ToInt32(parts[0]);
                int Klm = Convert.ToInt32(parts[1]);
                int Ults = Convert.ToInt32(parts[2]);
                string sys = Convert.ToString(parts[3]);
                guestt = Nut;
                tamu = Nut;
                lampu = Klm;
                air = Ults;
                id = sys;
                progressBar1.Value = Nut;
                guest.Text = Nut.ToString();
                SaveDataToCSV("tesss.csv");
                 if (Klm == 1)
                {
                    light.ForeColor = Color.Lime;
                    light.Text = "ON";
                    bulb.ForeColor = Color.Yellow;
                }
                else
                {
                    light.ForeColor = Color.Red;
                    light.Text = "OFF";
                    bulb.ForeColor = Color.White;
                }
                //ROOF.Text = Ults.ToString();
                if (Ults == 1)
                {
                    roof.ForeColor = Color.Lime;
                    roof.Text = "ON";
                    kanan.Location = new Point(850, 350);
                    kiri.Location = new Point(600, 350);

                }
                else
                {
                    roof.ForeColor = Color.Red;
                    roof.Text = "OFF";
                    kanan.Location = new Point(950, 350);
                    kiri.Location = new Point(500, 350);
                    

                }
               
                firebase_update();

                //progressBar1.Value = Nut;
                ID_RFID.Text = sys;
            }
            if (progressBar1.Value == progressBar1.Maximum)
            {
                // Kirim data maksimum ke Arduino
                arduinoSerialPort.WriteLine("STOP");

                // Tambahkan log jika diperlukan
                Console.WriteLine("Data maksimum dikirim ke Arduino.");
            }
            if (progressBar1.Value == 0)
            {
                // Kirim data maksimum ke Arduino
                arduinoSerialPort.WriteLine("START");

                // Tambahkan log jika diperlukan
                Console.WriteLine("Data maksimum dikirim ke Arduino.");
            }
        }
        private void progressBar1_ValueChanged(object sender, EventArgs e)
        {
            if (progressBar1.Value == progressBar1.Maximum)
            {
                // Kirim data maksimum ke Arduino
                arduinoSerialPort.WriteLine("STOP");

                // Tambahkan log jika diperlukan
                Console.WriteLine("Data maksimum dikirim ke Arduino.");
            }
        }

        private void pnl_connect_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void input_max_Click(object sender, EventArgs e)
        {
            int tamuMAX = Convert.ToInt32(max_input.Value);
            max.Text = tamuMAX.ToString();
            //arduinoSerialPort.WriteLine("START");
            progressBar1.Maximum = tamuMAX;
            //arduinoSerialPort.WriteLine("STOP");
            // kanan.Location = new Point(850, 350);
            //  kiri.Location = new Point(600, 350);
            // bulb.ForeColor = Color.Yellow;
        }   

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void max_input_ValueChanged(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
